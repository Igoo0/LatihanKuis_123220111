/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package latihankuis;

/**
 *
 * @author Lenovo
 */
public abstract class Division {
    String jenis;
    double WriteWeight;
    double CodingWeight;
    double InterviewWeight;
    
    public Division(String jenis, double WriteWeight,
            double CodingWeight, double InterviewWeight){
     this.jenis = jenis;
     this.WriteWeight = WriteWeight;
     this.CodingWeight = CodingWeight;
     this.InterviewWeight= InterviewWeight;
    }
    
    abstract double kalkulasi(Mahasiswa Mahasiswa);
}
