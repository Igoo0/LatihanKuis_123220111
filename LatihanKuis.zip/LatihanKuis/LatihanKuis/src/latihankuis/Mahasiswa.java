/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package latihankuis;

/**
 *
 * @author Lenovo
 */
public class Mahasiswa{
    int nim;
    String nama;
    double write;
    double coding;
    double interview;
    public Mahasiswa(int nim, String nama,
            double write, double coding, double interview){
        this.nim = nim;
        this.nama = nama;
        this.write = write;
        this.coding = coding;
        this.interview = interview;
    }
}
