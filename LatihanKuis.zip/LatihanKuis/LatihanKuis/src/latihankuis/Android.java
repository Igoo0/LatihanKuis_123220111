/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package latihankuis;

/**
 *
 * @author Lenovo
 */
public class Android extends Division{
    public Android(){
        super("Android Development", 0.25, 0.5, 0.25);
    }
    
    @Override
    double kalkulasi(Mahasiswa Mahasiswa){
        return (Mahasiswa.write * WriteWeight) + (Mahasiswa.coding * CodingWeight) +
                (Mahasiswa.interview * InterviewWeight);
    }
}
