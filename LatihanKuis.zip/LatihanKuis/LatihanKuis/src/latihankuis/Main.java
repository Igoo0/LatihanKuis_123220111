/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package latihankuis;
import java.util.Scanner;

/**
 *
 * @author Lenovo
 */
public class Main {
    static Scanner scanner = new Scanner(System.in);
    char edit = 'y';
    public static void main(String[] args){
        
        Division Android = new Android();
        Division WebBack = new WebBack();
        Division WebFront = new WebFront();
        Division division;
      
        System.out.println("Menu");
        System.out.println("1. Android Development");
        System.out.println("2. Web Development");
        System.out.println("0. Exit");
        System.out.println("Choose : ");
        int pilih = scanner.nextInt();
        
        switch(pilih){
            case 1:
            {
               division = Android;
               System.out.println("==Android Development==");
               Mahasiswa Mahasiswa = getInfo();
               
                System.out.println("Edit data? (y/n) : ");
                char edit = scanner.next().charAt(0);
                if (edit == 'y'){
                    editInfo(Mahasiswa);
                   
                    tampilData(Mahasiswa);
                    result(Mahasiswa, division);
                } else{
                    tampilData(Mahasiswa);
                    result(Mahasiswa, division);
                }
               
                
            }
            break;
            case 2:
            {
                System.out.println("==Web Development==");
                System.out.println("1. Front-End");
                System.out.println("2. Back-end");
                System.out.println("Choose : ");
                int pilih1 = scanner.nextInt();
                switch(pilih1){
                    case 1:
                    {
                        division = WebFront;
                        System.out.println("==Front-End Development==");
               Mahasiswa Mahasiswa = getInfo();
               
                System.out.println("Edit data? (y/n) : ");
                char edit = scanner.next().charAt(0);
                if (edit == 'y'){
                    editInfo(Mahasiswa);
                   
                    tampilData(Mahasiswa);
                    result(Mahasiswa, division);
                } else{
                    tampilData(Mahasiswa);
                    result(Mahasiswa, division);
                }
                    }
                    break;
                    case 2:
                    {
                        division = WebBack;
                        System.out.println("==Back-End Development==");
               Mahasiswa Mahasiswa = getInfo();
               
                System.out.println("Edit data? (y/n) : ");
                char edit = scanner.next().charAt(0);
                if (edit == 'y'){
                    editInfo(Mahasiswa);
                   
                    tampilData(Mahasiswa);
                    result(Mahasiswa, division);
                } else{
                    tampilData(Mahasiswa);
                    result(Mahasiswa, division);
                }
                    }
                    break;
                    default: System.out.println("Input salah");
                }
            }
            break;
            case 0:
                System.out.println("Terimakasih!");
            break;
            default:
                System.out.println("Input salah!");
        }
    }
    
    static Mahasiswa getInfo(){
        
        System.out.println("NIM      : ");
        int nim = scanner.nextInt();
        System.out.println("Nama     : ");
        String nama = scanner.next();
        System.out.println("Writing  : ");
        double write = scanner.nextDouble();
        System.out.println("Coding   : ");
        double coding = scanner.nextDouble();
        System.out.println("Interview     : ");
        double interview = scanner.nextDouble();
        return new Mahasiswa(nim, nama, write, coding, interview);
    }
    
    static void editInfo(Mahasiswa Mahasiswa){
        System.out.println("==Edit Data==");
        System.out.println("1. Writing");
        System.out.println("2. Coding");
        System.out.println("3. Interview");
        System.out.println("Choose : ");
        int pilih = scanner.nextInt();
        switch(pilih){
            case 1: 
            {
            System.out.println("Writing  : ");
            Mahasiswa.write = Double.parseDouble(scanner.next());
            }
        break;
            case 2:
            {
            System.out.println("Coding   : ");
            Mahasiswa.coding = Double.parseDouble(scanner.next());
            }
        break;
            case 3:
            {
            System.out.println("Interview     : ");
            Mahasiswa.interview = Double.parseDouble(scanner.next());
            }
            default: System.out.println("input salah");
            
        }
    }
    
    static void tampilData(Mahasiswa Mahasiswa){
        System.out.println("Data Final:");
        System.out.println("NIM: " + Mahasiswa.nim);
        System.out.println("Name: " + Mahasiswa.nama);
        System.out.println("Written Test: " + Mahasiswa.write);
        System.out.println("Coding Test: " + Mahasiswa.coding);
        System.out.println("Interview Test: " + Mahasiswa.interview);
    }
    
    static void result(Mahasiswa Mahasiswa, Division division){
        double skor = division.kalkulasi(Mahasiswa);
        if (skor>=85)
            System.out.println("Anda Lulus dengan skor " + skor);
        else
            System.out.println("Anda tidak lulus dengan skor " + skor);
    }
    
}
